package com.example.two;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ImageButton transbt = findViewById(R.id.bttrans);
        ImageButton scanbt = findViewById(R.id.btscan);
        ImageButton idenbt = findViewById(R.id.btiden);
        ImageButton vrbt = findViewById(R.id.btvr);

        transbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Translate", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, SecondTranslate.class);
                startActivity(intent);
            }
        });
        scanbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Scanner", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, SecondQr.class);
                startActivity(intent);
            }
        });
        idenbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Object Identifier", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, SecondIden.class);
                startActivity(intent);
            }
        });
        vrbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "AR", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, SecondAr.class);
            }
        });
    }
}